<div class="footer">
    <div class="copyright">
        <p>
            <?php echo e(__(Config::config()->copyright)); ?>

        </p>
    </div>
</div>
<?php /**PATH /home/fastskjp/public_html/main/resources/views/backend/layout/footer.blade.php ENDPATH**/ ?>