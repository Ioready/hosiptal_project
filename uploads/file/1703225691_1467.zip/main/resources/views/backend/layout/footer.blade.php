<div class="footer">
    <div class="copyright">
        <p>
            {{__(Config::config()->copyright)}}
        </p>
    </div>
</div>
