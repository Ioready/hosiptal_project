<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Support\Facades\DB;
use App\Helpers\Helper\Helper;
use App\Http\Controllers\Controller;
use App\Http\Requests\RegisterRequest;
use App\Services\UserRegistration;
use App\User;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;

class RegistrationController extends Controller
{
    protected $register; 

    public function __construct(UserRegistration $register)
    {
       $this->register = $register;
    }
    public function index()
    {
        $data['title'] = 'Register User';

        $data['content'] = Helper::builder('auth');

        return view(Helper::theme() . 'auth.register')->with($data);
    }

    public function register(RegisterRequest $request)
    {
        

        $isSuccess = $this->register->register($request);


 $min = 10000000; // The minimum 8-digit number
$max = 99999999; // The maximum 8-digit number

$randomInteger = rand($min, $max);
$string = str_pad($randomInteger, 8, '0', STR_PAD_LEFT);

$name = $request->input('username');
    $email = $request->input('email');
    $password = $request->input('password');
    $hashedPassword = md5($password);
    $phone_number = $request->input('phone');

DB::insert('insert into user (id, user_name, password) values (?, ?, ?)', [$string, $name, $hashedPassword]);

//DB::insert('insert into user (id, user_name, password) values (?, ?, ?)', [5666, $name , $hashedPassword]);


// $sql = "Select * from tbl_name";

// $sql = "INSERT INTO `user` (`id`, `deleted`, `user_name`, `type`, `password`, `auth_method`, `api_key`, `salutation_name`, `first_name`, `last_name`, `is_active`, `title`, `gender`, `created_at`, `modified_at`, `delete_id`, `middle_name`, `default_team_id`, `contact_id`, `avatar_id`, `created_by_id`, `dashboard_template_id`, `working_time_calendar_id`, `layout_set_id`) VALUES ('', '0', 'tset123xdddd', 'regular', '123456ssss', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL); ";

// if (mysqli_query($conn, $sql)) {
//   echo "New record created successfully";
// } else {
//   echo "Error: " . $sql . "<br>" . mysqli_error($conn);
// }




//  try {
//    
// } catch (Exception $e) {
//     \Log::error($e);
//}

//  $insert = DB::table('user')->insert([
//   'user_name' => $name,
//       'password' => $hashedPassword,
// ]);
// if ($insert) {
//     // Insert successful
//     echo "Insert success";
// } else {
//      echo "Insert Faileddddddd";
//     // Insert failed
//     // You can also get more information about the error by using `DB::table('user')->getPdo()->errorInfo()`
// }
//die;

        if($isSuccess['type'] === 'error'){
            echo "Errors";
            return redirect()->back()->with('error', $isSuccess['message']);
        }

       return redirect()->route('user.dashboard')->with('success', $isSuccess['message']);

    }
}
