<?php
    define('APP_URL', 'https://vipsmarkets.net/login');
    define('APP_URL_FORCE', false);

    define('FILE_PATH', '/login');

    define('MYSQL_HOST', 'localhost');  // MySQL Database host (localhost, 127.0.0.1, X.X.X.X, domain.tld)
    define('MYSQL_USER', 'vipsrvjp_db11');   // MySQL User (Please not use 'root', create a dedicated user with full permision user --> go doc)
    define('MYSQL_PASSWD', 'kS*e{NUKzXiP'); // MySQL Password
    define('MYSQL_PORT', '3306');        // MySQL Port (Set empty for not specify port)
    define('MYSQL_DATABASE', 'vipsrvjp_db11');        // MySQL Database (Use the file sql.sql for create sql requirement)

    define('CRYPTED_KEY', '2LWMdMCkP4yXb7ajY0BT92JIfLe4zfJan51OcA0lRGrbzJBNHjBJEMDJwIwk');
?>